/**
 * 
 */
/**
 * 
 */
module Solid4 {
}