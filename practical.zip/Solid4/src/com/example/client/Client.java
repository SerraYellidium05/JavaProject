package com.example.client;
import com.example.workers.Eater;
import com.example.workers.Human;
import com.example.workers.Robot;
import com.example.workers.Worker;

public class Client {

	public static void main(String[] args) {
		Worker robotwork=new Robot();
		Worker humanWork=new Human();
		Eater humanEater=(Eater) humanWorker;
		
		robotwork.work();
		humanWork.work();
		humanEater.eat();

	}

}
