package com.example.services;

public class EmailServices implements MessageService {
    public void sendMessage(String message, String recipient) {
        System.out.println("Sending Email to " + recipient + " with message: " + message);
    }
}