package com.example.services;

public interface MessageService {
    void sendMessage(String message, String recipient);
}