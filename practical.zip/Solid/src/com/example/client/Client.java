package com.example.client;
import com.example.employee.Employee;
import com.example.salary.SalaryCalculator;

public class Client {
	public static void main(String[] args) {
		mployee emp1 = new Employee("A", "B");
        Employee emp2 = new Employee("C", "D");
        Employee emp3 = new Employee("E", "F");
        SalaryCalculator salaryCalculator = new SalaryCalculator();
        System.out.println(emp1+"Salary"+salaryCalculator.calculatorSalary(emp1));
        System.out.println(emp1+"Salary"+salaryCalculator.calculatorSalary(emp2));
        System.out.println(emp1+"Salary"+salaryCalculator.calculatorSalary(emp3));
	}
}
