package com.example.salary;
import com.example.employee.Employee;
public class SalaryCalculator {
	public double calculateSalary(Employee employee) {
		double baseSalary;
		switch (employee.getRole()) {
        case "Manager":
            baseSalary = 5000.0;
            break;
        case "Developer":
            baseSalary = 4000.0;
            break;
        case "Designer":
            baseSalary = 3500.0;
            break;
        default:
            baseSalary = 3000.0;
            break;
    }

    return baseSalary;
}
}
