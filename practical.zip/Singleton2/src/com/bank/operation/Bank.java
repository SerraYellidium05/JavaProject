package com.bank.operation;
import com.bank;
public class Bank {
	private double balance;
	private Bank() {
		this.balance=0.0;
	}
	private static Bank instance=new Bank();
	public static Bank getInstance() {
		return instance;
	}
	public void viewbalance() {
		Ssytem.out.println("current balance"+balance);
	}
	public void deposit(double amount) {
		if(amount>0) {
			balance+=amount;
			System.out.println("New balance"+balance);
		}
		else {
			System.out.println("not deposited");
		}
	}
	public void withdraw(double amount) {
		if(amount>0) {
			balance-=amount;
			System.out.println("withdraw"+amount);
		}
		else {
			System.out.println("No withdraw");
		}
	}
}
