/**
 * 
 */
/**
 * 
 */
module Solid3 {
}