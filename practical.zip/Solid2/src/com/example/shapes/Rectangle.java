package com.example.shapes;

public abstract class Shape {
	public abstract double calculateArea();
}

